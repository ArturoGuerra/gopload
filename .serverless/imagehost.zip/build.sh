#!/bin/sh

rm -rf bin/server
go build -o bin/server
